# Vold EHX Tool - Windows Distribution

## Overview
Vold.exe is a standalone Windows executable for processing EHX files. This application provides a GUI interface for EHX file analysis, panel takeoff calculations, and material breakdowns.

## System Requirements
- Windows 10 or later
- No Python installation required (all dependencies are bundled)

## Installation
1. Download `Vold.exe` from the distribution package
2. Place the executable in your desired location
3. Double-click `Vold.exe` to run the application

## Features
- EHX file loading and parsing
- Panel takeoff calculations
- Material breakdown analysis
- GUI interface with state persistence
- Debug logging capabilities

## Usage
1. Launch Vold.exe
2. Use the GUI to load EHX files
3. Process panels and view calculations
4. Export results as needed

## Files Included
- `Vold.exe` - Main application executable
- State files are created automatically on first run

## Troubleshooting
- If the application doesn't start, check Windows security settings
- Ensure you have write permissions in the application directory
- Check the LOG directory for debug information if issues occur

## Technical Details
- Built with PyInstaller for standalone distribution
- Includes all Python dependencies
- GUI built with tkinter
- State persistence using JSON files

## Version
Built on: 2025-10-31
Python version: 3.13.2
PyInstaller version: 6.16.0