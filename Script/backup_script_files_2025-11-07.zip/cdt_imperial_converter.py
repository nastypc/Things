#!/usr/bin/env python3
"""
CDT Imperial Conversion Script

This script processes MiTek .CDT files to add imperial (feet-inches-sixteenths)
conversions as TXT: comments below coordinate lines, and replaces STE lines with TXT:.

Usage: python cdt_imperial_converter.py <input_file.cdt> [output_suffixes]

Example: python cdt_imperial_converter.py P1.CDT A B C
"""

import sys
import os
import re
from pathlib import Path

def mm_to_feet_inches_sixteenths(mm_value):
    """Convert millimeters to feet-inches-sixteenths format."""
    # Convert mm to inches
    inches = mm_value / 25.4

    # Calculate feet and remaining inches
    feet = int(inches // 12)
    remaining_inches = inches % 12

    # Convert remaining inches to sixteenths
    sixteenths = round(remaining_inches * 16 / 12)

    # Handle the formatting
    if sixteenths == 0:
        # No sixteenths, just show feet (without -0")
        if feet == 0:
            return "0'"
        else:
            return f"{feet}'"
    else:
        # Calculate inches and sixteenths
        inches_whole = sixteenths // 16
        sixteenths_remainder = sixteenths % 16

        if sixteenths_remainder == 0:
            # Exact inches
            if inches_whole == 0:
                return f"{feet}'"
            else:
                return f"{feet}'-{inches_whole}\""
        else:
            # Fractional inches
            fraction = ""
            if sixteenths_remainder == 2:
                fraction = "1/8"
            elif sixteenths_remainder == 4:
                fraction = "1/4"
            elif sixteenths_remainder == 6:
                fraction = "3/8"
            elif sixteenths_remainder == 8:
                fraction = "1/2"
            elif sixteenths_remainder == 10:
                fraction = "5/8"
            elif sixteenths_remainder == 12:
                fraction = "3/4"
            elif sixteenths_remainder == 14:
                fraction = "7/8"
            else:
                fraction = f"{sixteenths_remainder}/16"

            if inches_whole == 0:
                return f"{feet}'-{fraction}\""
            else:
                return f"{feet}'-{inches_whole} {fraction}\""

def parse_coordinate_line(line):
    """Parse a coordinate line and extract numeric values."""
    numbers = re.findall(r'(\d+\.?\d*)', line)
    return [float(num) for num in numbers]

def convert_coordinate_line(line):
    """Convert a coordinate line to imperial format."""
    numbers = parse_coordinate_line(line)

    # Convert each number to imperial
    imperial_parts = []
    for num in numbers:
        imperial = mm_to_feet_inches_sixteenths(num)
        imperial_parts.append(imperial)

    # Reconstruct the line with imperial values
    result_parts = []
    num_index = 0

    parts = line.split(':')
    for i, part in enumerate(parts):
        part = part.strip()
        if re.match(r'^\d+\.?\d*$', part) and num_index < len(imperial_parts):
            result_parts.append(imperial_parts[num_index])
            num_index += 1
        else:
            result_parts.append(part)

    return ':'.join(result_parts)

def process_cdt_file(input_file, output_suffix):
    """Process a single CDT file and create imperial version."""
    input_path = Path(input_file)
    output_file = input_path.parent / f"{input_path.stem}_{output_suffix}{input_path.suffix}"

    print(f"Processing {input_file} -> {output_file}")

    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    processed_lines = []

    for line in lines:
        line = line.strip()
        if not line:
            processed_lines.append("")
            continue

        # Check if this line contains coordinates
        numbers = parse_coordinate_line(line)

        # Add the original line
        processed_lines.append(line)

        # Add imperial conversion for coordinate lines
        if len(numbers) >= 3:  # Lines with 3+ coordinates get imperial conversion
            imperial_line = convert_coordinate_line(line)
            processed_lines.append(f"TXT:{imperial_line}")
        elif line.startswith('STE'):  # Replace STE with TXT:
            processed_lines.append("TXT:")
        else:
            # For other lines, just add the original
            pass

    # Write the output file
    with open(output_file, 'w', encoding='utf-8') as f:
        for line in processed_lines:
            f.write(line + '\n')

    print(f"Created {output_file}")

def main():
    if len(sys.argv) < 3:
        print("Usage: python cdt_imperial_converter.py <input_file.cdt> <suffix1> [suffix2] [suffix3] ...")
        print("Example: python cdt_imperial_converter.py P1.CDT A B C")
        sys.exit(1)

    input_file = sys.argv[1]

    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' not found.")
        sys.exit(1)

    # Process each suffix
    for suffix in sys.argv[2:]:
        process_cdt_file(input_file, suffix)

    print("All conversions completed!")

if __name__ == "__main__":
    main()</content>
<parameter name="filePath">c:\Users\edward\Downloads\EHX\Script\cdt_imperial_converter.py